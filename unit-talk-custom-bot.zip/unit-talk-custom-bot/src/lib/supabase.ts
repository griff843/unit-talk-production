// Supabase configuration for the custom bot
export const supabase = null; // Placeholder - replace with actual Supabase client
export const isSupabaseConfigured = false;

// Mock functions for compatibility
export const createClient = () => null;
export const getSupabaseUrl = () => '';
export const getSupabaseAnonKey = () => '';